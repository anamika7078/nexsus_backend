const { DataTypes } = require('sequelize');
const bcrypt = require('bcryptjs');
const sequelize = require('../config/database');

const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
        validate: {
            isEmail: true
        }
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    role: {
        type: DataTypes.STRING,
        defaultValue: 'admin'
    },
    name: {
        type: DataTypes.STRING,
        defaultValue: ''
    },
    provider: {
        type: DataTypes.STRING,
        defaultValue: 'local'
    },
    phone: {
        type: DataTypes.STRING,
        defaultValue: ''
    },
    companyName: {
        type: DataTypes.STRING,
        defaultValue: 'Nexsus Cyber Solutions'
    },
    emailNotifications: {
        type: DataTypes.JSON,
        defaultValue: {
            newLeads: true,
            weeklySummary: true,
            systemUpdates: true
        }
    },
    refreshTokens: {
        type: DataTypes.JSON,
        defaultValue: []
    },
    lastLogin: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    }
}, {
    timestamps: true,
    hooks: {
        beforeCreate: async (user) => {
            if (user.password) {
                const salt = await bcrypt.genSalt(10);
                user.password = await bcrypt.hash(user.password, salt);
            }
        },
        beforeUpdate: async (user) => {
            if (user.changed('password')) {
                const salt = await bcrypt.genSalt(10);
                user.password = await bcrypt.hash(user.password, salt);
            }
        }
    }
});

// Instance method to compare password
User.prototype.comparePassword = async function (candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

module.exports = User;
